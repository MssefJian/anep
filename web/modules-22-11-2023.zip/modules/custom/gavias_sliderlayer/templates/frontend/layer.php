<div id="<?php print $layer_id ?>" <?php print $attributes;?>  data-type="text" data-frames='<?php print $data_frames ?>'>
  <?php print $content; ?>
</div>

